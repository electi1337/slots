const symbols = ['🍒', '🍋', '🍊', '🍉', '🍇'];
let balance = 0;
let secondsPerSpin = 0

function spin() {
  if (balance < 10) {
    alert("Insufficient balance!");
    return;
  }

  balance -= 10;
  document.getElementById('balance').textContent = balance.toFixed(2);

  const slots = document.querySelectorAll('.slot');

  // Start the spinning animation for each slot
  slots.forEach(slot => {
    slot.classList.remove('spinning-slot');
  });

  setTimeout(() => {
    // Generate random symbols for each slot
    const symbol1 = symbols[Math.floor(Math.random() * symbols.length)];
    const symbol2 = symbols[Math.floor(Math.random() * symbols.length)];
    const symbol3 = symbols[Math.floor(Math.random() * symbols.length)];

    // Display the symbols in the slots
    document.getElementById('slot1').textContent = symbol1;
    document.getElementById('slot2').textContent = symbol2;
    document.getElementById('slot3').textContent = symbol3;

    // Check for winning combinations
    if (symbol1 === symbol2 && symbol2 === symbol3) {
      balance *= 2; // Double the balance
      document.getElementById('result').textContent = "You Doubled Your Balance!";
    } else {
      document.getElementById('result').textContent = "You Lose!";
    }

    // Stop the spinning animation
    slots.forEach(slot => {
      slot.classList.add('spinning-slot');
    });
  }, secondsPerSpin * 1000);
}

// Function to add 1 dollar every second
setInterval(() => {
  balance += 1;
  document.getElementById('balance').textContent = balance.toFixed(2);
}, 1000);